const RecTextItem = () => {
  return <div></div>;
};

export default RecTextItem;
