export { default as Detail } from './DetailCard'
export { default as DramaPosterGallery } from './DetailPosterGallery';
export { default as EpisodeCard } from './EpisodeCard';
export { default as ReviewCard } from './ReviewCard';
export { default as InfoCard } from './InfoCard';
export { default as Certification } from './Certification';
