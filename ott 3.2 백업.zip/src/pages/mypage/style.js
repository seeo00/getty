import styled from 'styled-components';

export const MypageContainer = styled.div`
  min-height: 100svh;
  margin-bottom: 28px;
`;
