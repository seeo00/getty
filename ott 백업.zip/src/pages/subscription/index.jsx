import { SubscriptionContent } from '../../components';

const Subscription = () => {
  return (
    <>
      <SubscriptionContent />
    </>
  );
};

export default Subscription;
