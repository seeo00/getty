// import { MyPageWrapper } from '../style';
import SubscriptionContent from '../../../components/mypage/subscription/SubscriptionContent';

const Subscription = () => {
  return (
    <>
      <SubscriptionContent />
    </>
  );
};

export default Subscription;
