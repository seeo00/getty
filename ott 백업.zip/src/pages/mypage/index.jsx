const MyPage = () => {
  return (
    <div>
      마이페이지
      {/* <Outlet /> */}
    </div>
  );
};

export default MyPage;
