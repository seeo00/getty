// import styled from 'styled-components';

// export const MyPageWrapper = styled.div`
//   background-color: #121212;
//   min-height: 100vh;
//   color: white;
//   padding-top: 0;
// `;
